pub fn hello_world() -> String {
        String::from("Hello from Rust! 🦀")
}